public enum UserRole {
    ADMIN,
    EMPLOYEE
}
