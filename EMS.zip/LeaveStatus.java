public enum LeaveStatus {
    PENDING, APPROVED, REJECTED
}

